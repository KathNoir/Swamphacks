package com.example.swamphacks_project;

import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import com.example.swamphacks_project.databinding.ActivityHomeBinding;


public class Home extends FragmentActivity {

    private ActivityHomeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

    }

}
