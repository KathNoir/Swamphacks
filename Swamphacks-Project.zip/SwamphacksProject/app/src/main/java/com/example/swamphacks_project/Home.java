package com.example.swamphacks_project;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.FragmentActivity;

import com.example.swamphacks_project.databinding.ActivityHomeBinding;


public class Home extends FragmentActivity {

    private ActivityHomeBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Button updateButton = findViewById(R.id.updateButton);
        updateButton.setOnClickListener(view -> reloadMap());

        
    }

    private void reloadMap() {
        Intent enterMap = new Intent(this, MapsActivity.class);
        startActivity(enterMap);
    }


}
